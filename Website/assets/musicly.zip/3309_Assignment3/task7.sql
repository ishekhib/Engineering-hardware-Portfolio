USE musicly_db;
SET SQL_SAFE_UPDATES = 0;
-- Feature 1: Create a favourites songs compilation playlist

-- 1. CLEANUP: Remove the failed/partial playlist
DELETE FROM Playlist WHERE name = 'Community Favorites';

-- 2. FORCE DISTINCT MATCHES (The Fix)
-- We map the first 10 Users to the first 10 Songs (1-to-1 mapping).
-- This guarantees 10 DIFFERENT songs are favored.
UPDATE `User` u
JOIN (
    SELECT username, ROW_NUMBER() OVER (ORDER BY username) as rn 
    FROM `User` LIMIT 10
) as user_rows ON u.username = user_rows.username
JOIN (
    SELECT name, ROW_NUMBER() OVER (ORDER BY songID) as rn 
    FROM Song LIMIT 10
) as song_rows ON user_rows.rn = song_rows.rn
SET u.favTrack = song_rows.name;

-- 3. CREATE the Playlist Header
INSERT INTO Playlist (name, username, description) 
SELECT 'Community Favorites', (SELECT username FROM `User` LIMIT 1), 'Top 10 User Favorites';

-- 4. POPULATE the Playlist
-- Now this will insert 10 UNIQUE song IDs, avoiding the "Duplicate Entry" error.
INSERT INTO Playlist_Songs (playlistID, songID)
SELECT 
    (SELECT playlistID FROM Playlist WHERE name = 'Community Favorites' LIMIT 1),
    Song.songID
FROM Song
JOIN `User` ON Song.name = `User`.favTrack
LIMIT 10;

-- 5. RE-ENABLE SAFE MODE
SET SQL_SAFE_UPDATES = 1;

-- 6. VERIFY (Should show exactly 10 distinct rows)
SELECT Playlist.name, Song.name AS TrackName, `User`.username AS Fan
FROM Playlist
JOIN Playlist_Songs ON Playlist.playlistID = Playlist_Songs.playlistID
JOIN Song ON Playlist_Songs.songID = Song.songID
JOIN `User` ON Song.name = `User`.favTrack
WHERE Playlist.name = 'Community Favorites';



-- Feature 2: Fully deletes an artist
DELETE FROM Artist WHERE name = 'Todd Bean';

-- Feature 3: Copies a playlist
INSERT INTO Playlist (name, username, description)
SELECT CONCAT('Copy of ', name), username, description 
FROM Playlist WHERE playlistID = 1;
SELECT 'Copy of Community Favorites' FROM playlist


