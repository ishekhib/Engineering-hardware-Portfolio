USE musicly_db;
-- Query 1: JOIN (Basic)
-- Find all songs and their artists
SELECT Artist.name AS Artist, Song.name AS Track
FROM Song
JOIN Album ON Song.albumID = Album.albumID
JOIN Artist ON Album.artistID = Artist.artistID
LIMIT 20;

-- Query 2: GROUP BY & AGGREGATE (Intermediate)
-- Count how many albums each artist has
SELECT Artist.name, COUNT(Album.albumID) as AlbumCount
FROM Artist
JOIN Album ON Artist.artistID = Album.artistID
GROUP BY Artist.name
ORDER BY AlbumCount DESC;

-- Query 3: SUBQUERY (Interesting)
-- Find songs longer than the average song length
SELECT name, runtime 
FROM Song
WHERE runtime > (SELECT AVG(runtime) FROM Song);


-- Query 4: COMPLEX JOIN (Interesting)
-- Show reviews for a specific song name
SELECT User.username, Review.rating, Review.content
FROM Review
JOIN SongReview ON Review.reviewID = SongReview.reviewID
JOIN Song ON SongReview.songID = Song.songID
JOIN User ON Review.username = User.username
WHERE Song.name LIKE 'Blinding Lights';

-- Query 5: EXISTS (Interesting)
-- Find artists who have at least one album released
SELECT name FROM Artist a
WHERE EXISTS (SELECT 1 FROM Album al WHERE al.artistID = a.artistID);

-- Query 6: DATE FILTERING (Basic)
-- Find albums released after 2020
SELECT * FROM Album WHERE releaseDate > '2020-01-01';

-- Query 7: GROUP BY with HAVING (Interesting)
-- Find genres that have more than 5 songs (assuming you ran the Python script)
SELECT Genre.name, COUNT(Song.songID) as SongCount
FROM Genre
JOIN Song ON Genre.genreID = Song.genreID
GROUP BY Genre.name
HAVING SongCount > 5;