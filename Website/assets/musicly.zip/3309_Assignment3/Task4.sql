USE musicly_db;

-- 1. Standard Insert (All Columns)
INSERT INTO `User` (username, profilePicture, favTrack, favArtist, favAlbum) 
VALUES ('jack_ryan', 'profile.jpg', 'Blinding Lights', 'The Weeknd', 'After Hours');

-- 2. Partial Insert (Only Primary Key)
-- This demonstrates handling nullable columns
INSERT INTO `User` (username) 
VALUES ('guest_user_01');

-- 3. Insert using SELECT (Creating a copy/derivative)
-- We create a 'backup' account for jack_ryan by selecting his data
INSERT INTO `User` (username, favArtist, favAlbum)
SELECT CONCAT(username, '_backup'), favArtist, favAlbum
FROM `User` 
WHERE username = 'jack_ryan';

-- Show results
SELECT * FROM `User`;