USE musicly_db;

-- =========================================================
-- REQUIREMENT 1: CREATE TWO VIEWS
-- =========================================================

-- View 1: AlbumStats (Complex View)
-- Shows album info with a count of songs.
-- Status: NOT Updatable (Contains GROUP BY and Aggregate functions).
CREATE OR REPLACE VIEW AlbumStats AS
SELECT Album.name AS AlbumName, Artist.name AS ArtistName, COUNT(Song.songID) AS TrackCount
FROM Album
JOIN Artist ON Album.artistID = Artist.artistID
JOIN Song ON Album.albumID = Song.albumID
GROUP BY Album.albumID;

-- View 2: HighRatings (Simple View)
-- Shows all reviews with 4 or 5 stars.
-- Status: Updatable (Direct selection from one table, no aggregates).
CREATE OR REPLACE VIEW HighRatings AS
SELECT * FROM Review WHERE rating >= 4;

-- =========================================================
-- REQUIREMENT 2: QUERY EACH VIEW
-- =========================================================

-- Query 1: Check statistics for albums
SELECT * FROM AlbumStats ORDER BY TrackCount DESC LIMIT 5;

-- Query 2: Check recent high reviews
SELECT * FROM HighRatings LIMIT 5;

-- =========================================================
-- REQUIREMENT 3: ATTEMPT TO MODIFY (THE TEST)
-- =========================================================

-- We try to INSERT a new row into the 'AlbumStats' view.
-- THIS WILL FAIL. You need to screenshot the RED ERROR message at the bottom.
INSERT INTO AlbumStats (AlbumName, ArtistName, TrackCount)
VALUES ('Test Album', 'Test Artist', 12);