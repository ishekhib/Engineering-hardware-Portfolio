-- AISE 3309 Assignment 3 - Group 10
-- Task 3: Database Schema Creation

DROP DATABASE IF EXISTS musicly_db;
CREATE DATABASE musicly_db;
USE musicly_db;

-- 1. Create Tables
CREATE TABLE Artist (
    artistID INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    picture VARCHAR(255)
);

CREATE TABLE Genre (
    genreID INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE Album (
    albumID INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    cover VARCHAR(255),
    releaseDate DATE,
    artistID INT,
    CONSTRAINT fk_album_artist FOREIGN KEY (artistID) REFERENCES Artist(artistID)
);

CREATE TABLE Song (
    songID INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    runtime INT,
    trackNum INT,
    albumID INT,
    genreID INT,
    CONSTRAINT fk_song_album FOREIGN KEY (albumID) REFERENCES Album(albumID) ON DELETE CASCADE,
    CONSTRAINT fk_song_genre FOREIGN KEY (genreID) REFERENCES Genre(genreID)
);

CREATE TABLE User (
    username VARCHAR(50) PRIMARY KEY,
    profilePicture VARCHAR(255),
    favTrack VARCHAR(100),
    favArtist VARCHAR(100),
    favAlbum VARCHAR(100)
);

CREATE TABLE Playlist (
    playlistID INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    username VARCHAR(50),
    CONSTRAINT fk_playlist_user FOREIGN KEY (username) REFERENCES User(username) ON DELETE CASCADE
);

CREATE TABLE Playlist_Songs (
    playlistID INT,
    songID INT,
    PRIMARY KEY (playlistID, songID),
    CONSTRAINT fk_ps_playlist FOREIGN KEY (playlistID) REFERENCES Playlist(playlistID) ON DELETE CASCADE,
    CONSTRAINT fk_ps_song FOREIGN KEY (songID) REFERENCES Song(songID) ON DELETE CASCADE
);

CREATE TABLE Review (
    reviewID INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50),
    rating INT CHECK (rating BETWEEN 1 AND 5),
    content TEXT,
    reviewDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_review_user FOREIGN KEY (username) REFERENCES User(username)
);

CREATE TABLE SongReview (
    reviewID INT PRIMARY KEY,
    songID INT,
    CONSTRAINT fk_sr_review FOREIGN KEY (reviewID) REFERENCES Review(reviewID) ON DELETE CASCADE,
    CONSTRAINT fk_sr_song FOREIGN KEY (songID) REFERENCES Song(songID) ON DELETE CASCADE
);

CREATE TABLE AlbumReview (
    reviewID INT PRIMARY KEY,
    albumID INT,
    CONSTRAINT fk_ar_review FOREIGN KEY (reviewID) REFERENCES Review(reviewID) ON DELETE CASCADE,
    CONSTRAINT fk_ar_album FOREIGN KEY (albumID) REFERENCES Album(albumID) ON DELETE CASCADE
);

-- 2. DESCRIBE COMMANDS 
-- Run these one by one and screenshot the result grid for each.
DESCRIBE Artist;
DESCRIBE Genre;
DESCRIBE Album;
DESCRIBE Song;
DESCRIBE User;
DESCRIBE Playlist;
DESCRIBE Playlist_Songs;
DESCRIBE Review;
DESCRIBE SongReview;
DESCRIBE AlbumReview;